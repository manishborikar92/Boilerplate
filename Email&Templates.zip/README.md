# CA-Flow Email Templates - Modernized Version

## 📋 Overview

This is a modernized, production-ready email template system for CA-Flow. The code has been completely refactored using modern JavaScript patterns, best practices, and improved architecture.

## ✨ What's New - Modernization Highlights

### 1. **Object-Oriented Architecture**
- ✅ Converted from functional approach to **class-based architecture**
- ✅ Each template is now a separate class extending `EmailTemplate`
- ✅ Better encapsulation and inheritance
- ✅ Easier to extend and maintain

**Before:**
```javascript
const template1_ClassicProfessional = ({ title, content, actionUrl, actionLabel }) => `...`;
```

**After:**
```javascript
class ClassicProfessional extends EmailTemplate {
  render({ title, content, actionUrl, actionLabel }) {
    // ...
  }
}
```

### 2. **Template Registry Pattern**
- ✅ Centralized template management with `TemplateRegistry`
- ✅ Easy template discovery and selection
- ✅ Dynamic template loading
- ✅ Built-in template listing and metadata

**Usage:**
```javascript
const template = TemplateRegistry.getTemplate('modernGradient');
const allTemplates = TemplateRegistry.listTemplates();
```

### 3. **Utility Classes & Helper Methods**
- ✅ `EmailStyles` class for centralized style management
- ✅ `TemplateBuilder` with reusable component builders
- ✅ `SampleContentGenerator` for testing and previews
- ✅ DRY (Don't Repeat Yourself) principles applied

**Example:**
```javascript
// Centralized button creation
TemplateBuilder.createButton(url, label, customStyles);

// Centralized footer creation
TemplateBuilder.createFooter(additionalText);
```

### 4. **Better Type Documentation**
- ✅ Comprehensive JSDoc comments throughout
- ✅ TypeScript-style type definitions using `@typedef`
- ✅ Parameter and return type documentation
- ✅ Better IDE autocomplete support

**Example:**
```javascript
/**
 * @typedef {Object} TemplateConfig
 * @property {string} title - Email subject/heading
 * @property {string} content - HTML content body
 * @property {string} [actionUrl] - Optional CTA button URL
 * @property {string} [actionLabel] - Optional CTA button text
 */
```

### 5. **Improved Code Organization**
- ✅ Logical section grouping with clear separators
- ✅ Consistent naming conventions (PascalCase for classes, camelCase for methods)
- ✅ Single Responsibility Principle for each class
- ✅ Separation of concerns (styles, templates, utilities)

### 6. **Enhanced Flexibility**
- ✅ Customizable button styles per template
- ✅ Optional parameters properly handled
- ✅ Easy to add new templates without touching existing code
- ✅ Template inheritance for variant creation

### 7. **Modern Export System**
- ✅ Named exports for better tree-shaking
- ✅ Convenience methods exported at module level
- ✅ Clear export organization
- ✅ Both class and instance exports

**Usage:**
```javascript
// Import what you need
const { getTemplate, listTemplates } = require('./email-templates');

// Or import specific classes
const { ModernGradient, TemplateBuilder } = require('./email-templates');
```

### 8. **Better Error Handling**
- ✅ Null checks in registry methods
- ✅ Graceful handling of missing templates
- ✅ Clear error messages
- ✅ Validation in utility methods

### 9. **Testability**
- ✅ Pure functions where possible
- ✅ Dependency injection ready
- ✅ Easy to mock and test
- ✅ Sample generator for automated testing

### 10. **Performance Optimizations**
- ✅ Static methods where state isn't needed
- ✅ Template instances created once and reused
- ✅ Efficient string concatenation
- ✅ Minimal object creation in hot paths

## 🏗️ Architecture

```
email-templates.js
├── EmailStyles (Utility Class)
│   ├── base (CSS styles)
│   └── currentYear (Dynamic year)
│
├── TemplateBuilder (Utility Class)
│   ├── createDocument()
│   ├── createButton()
│   └── createFooter()
│
├── EmailTemplate (Base Class)
│   └── render() [abstract method]
│
├── Template Classes (10 variants)
│   ├── ClassicProfessional
│   ├── ModernGradient
│   ├── MinimalClean
│   ├── BorderedCard
│   ├── SideAccent
│   ├── DarkHeader
│   ├── SoftRounded
│   ├── TwoTone
│   ├── ElegantSerif
│   └── TechModern
│
├── TemplateRegistry (Template Manager)
│   ├── getTemplate()
│   ├── getAllTemplates()
│   └── listTemplates()
│
└── SampleContentGenerator (Testing Utility)
    ├── createSampleContent()
    └── generateSample()
```

## 📦 Installation

```bash
# Install dependencies
npm install

# Copy environment configuration
cp .env.example .env

# Edit .env with your email credentials
nano .env
```

## 🚀 Quick Start

### Basic Usage

```javascript
const { getTemplate } = require('./email-templates');

// Get a template
const template = getTemplate('modernGradient');

// Render an email
const emailHtml = template.render({
  title: 'Welcome to CA-Flow',
  content: '<p>Hello! Your account is ready.</p>',
  actionUrl: 'https://ca-flow.com/dashboard',
  actionLabel: 'Get Started'
});

// Send via your email service
sendEmail(recipientEmail, emailHtml);
```

### List Available Templates

```javascript
const { listTemplates } = require('./email-templates');

const templates = listTemplates();
templates.forEach(({ key, name, description }) => {
  console.log(`${key}: ${name}`);
  console.log(`  ${description}\n`);
});
```

### Generate Sample Preview

```javascript
const { generateSample } = require('./email-templates');

// Quick preview with default content
const preview = generateSample('classicProfessional');

// Save to file for testing
require('fs').writeFileSync('preview.html', preview);
```

### Dynamic Template Selection

```javascript
const { getTemplate } = require('./email-templates');

function getTemplateForEmailType(emailType) {
  const mapping = {
    'welcome': 'modernGradient',
    'invoice': 'classicProfessional',
    'notification': 'minimalClean',
    'alert': 'darkHeader'
  };
  
  return getTemplate(mapping[emailType] || 'classicProfessional');
}

const template = getTemplateForEmailType('welcome');
```

### Dynamic Template Selection

```javascript
const { getTemplate } = require('./email-templates');

function getTemplateForEmailType(emailType) {
  const mapping = {
    'welcome': 'modernGradient',
    'invoice': 'classicProfessional',
    'notification': 'minimalClean',
    'alert': 'darkHeader'
  };
  
  return getTemplate(mapping[emailType] || 'classicProfessional');
}

const template = getTemplateForEmailType('welcome');
```

## 📧 Sending Emails

The package includes a script to send all 10 templates to your inbox for review.

### Setup Email Configuration

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Edit `.env` with your email credentials:
```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
RECIPIENT_EMAIL=manishborikar07@gmail.com
```

### Gmail Setup (Recommended for Testing)

1. Enable 2-Factor Authentication on your Google account
2. Go to [Google App Passwords](https://myaccount.google.com/apppasswords)
3. Generate an App Password for "Mail"
4. Use that password in `EMAIL_PASS` (not your regular password)

### Send Commands

```bash
# Send all 10 templates (with 2-second delay between each)
npm run send:all

# Send a single test email
npm run send:test

# List all available templates
npm run templates:list

# Show help
npm run help
```

### Manual Email Sending

```javascript
const nodemailer = require('nodemailer');
const { getTemplate } = require('./email-templates');

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-app-password'
  }
});

const template = getTemplate('modernGradient');
const html = template.render({
  title: 'Welcome to CA-Flow',
  content: '<p>Your account is ready!</p>',
  actionUrl: 'https://ca-flow.com/dashboard',
  actionLabel: 'Get Started'
});

transporter.sendMail({
  from: 'noreply@ca-flow.com',
  to: 'user@example.com',
  subject: 'Welcome to CA-Flow',
  html: html
});
```

## 📚 API Reference

### TemplateRegistry

#### `getTemplate(name: string): EmailTemplate | null`
Returns a template instance by name.

```javascript
const template = TemplateRegistry.getTemplate('modernGradient');
```

#### `getAllTemplates(): Object`
Returns all template instances.

```javascript
const allTemplates = TemplateRegistry.getAllTemplates();
```

#### `listTemplates(): Array<{key, name, description}>`
Returns metadata for all templates.

```javascript
const list = TemplateRegistry.listTemplates();
```

### EmailTemplate

#### `render(config: TemplateConfig): string`
Renders the template with the provided configuration.

```javascript
const html = template.render({
  title: 'Email Title',
  content: '<p>Email content</p>',
  actionUrl: 'https://example.com',  // optional
  actionLabel: 'Click Here'          // optional
});
```

### TemplateBuilder

#### `createDocument(title: string, body: string): string`
Creates complete HTML document structure.

#### `createButton(url, label, styles): string`
Creates a CTA button with custom styles.

```javascript
const button = TemplateBuilder.createButton(
  'https://example.com',
  'Click Me',
  { background: '#ff0000', borderRadius: '8px' }
);
```

#### `createFooter(additionalText): string`
Creates footer with copyright text.

### SampleContentGenerator

#### `createSampleContent(recipientName): string`
Generates sample email content.

#### `generateSample(templateName, customConfig): string`
Generates a complete sample email.

```javascript
const sample = SampleContentGenerator.generateSample(
  'modernGradient',
  { title: 'Custom Title' }
);
```

## 🎨 Available Templates

| Template | Key | Description | Use Case |
|----------|-----|-------------|----------|
| Classic Professional | `classicProfessional` | Traditional corporate design | Formal communications, invoices |
| Modern Gradient | `modernGradient` | Contemporary with gradient | Welcome emails, announcements |
| Minimal Clean | `minimalClean` | Ultra-clean white space | Simple notifications |
| Bordered Card | `borderedCard` | Card-style with borders | Documents, reports |
| Side Accent | `sideAccent` | Colorful left border | Highlights, important notices |
| Dark Header | `darkHeader` | Bold dark header | Professional, modern look |
| Soft Rounded | `softRounded` | Friendly rounded corners | Customer-facing, friendly |
| Two-Tone | `twoTone` | Contrasting sections | Structured content |
| Elegant Serif | `elegantSerif` | Sophisticated serif | Premium, formal |
| Tech Modern | `techModern` | Tech-inspired dark | Developer-focused, tech |

## 🔧 Extending the System

### Adding a New Template

```javascript
class MyCustomTemplate extends EmailTemplate {
  constructor() {
    super('My Custom', 'Description of my template');
  }

  render({ title, content, actionUrl, actionLabel }) {
    const body = `
      <body style="margin:0;padding:0;">
        <!-- Your custom template HTML -->
      </body>
    `;
    
    return TemplateBuilder.createDocument(title, body);
  }
}

// Register it
TemplateRegistry.templates.myCustom = new MyCustomTemplate();
```

### Customizing Button Styles

```javascript
class CustomizedTemplate extends ModernGradient {
  render(config) {
    // Override button creation
    const originalRender = super.render(config);
    return originalRender; // With modifications
  }
}
```

## 📊 Comparison: Before vs After

| Aspect | Before | After |
|--------|--------|-------|
| Structure | Functional | Object-Oriented (Classes) |
| Reusability | Medium | High (Utility classes) |
| Extensibility | Hard | Easy (Inheritance) |
| Type Safety | None | JSDoc types |
| Template Discovery | Manual | TemplateRegistry |
| Code Duplication | High | Low (DRY) |
| Testability | Medium | High |
| Maintenance | Hard | Easy |
| Performance | Good | Optimized |
| Documentation | Basic | Comprehensive |

## 🧪 Testing

```javascript
// test-templates.js
const { listTemplates, generateSample } = require('./email-templates');

describe('Email Templates', () => {
  test('All templates should render', () => {
    const templates = listTemplates();
    
    templates.forEach(({ key }) => {
      const html = generateSample(key);
      expect(html).toContain('<!DOCTYPE html>');
      expect(html).toContain('CA-Flow');
    });
  });
});
```

## 📝 Best Practices

1. **Always use the registry** - Don't instantiate template classes directly
2. **Sanitize user content** - Always escape HTML in content parameter
3. **Test rendering** - Use `generateSample()` for testing before sending
4. **Cache template instances** - TemplateRegistry already does this
5. **Use JSDoc types** - Helps with IDE autocomplete and type checking

## 🔄 Migration Guide

### From Old Code

```javascript
// OLD WAY
const template1_ClassicProfessional = require('./templates');
const html = template1_ClassicProfessional({
  title: 'Test',
  content: '<p>Content</p>'
});

// NEW WAY
const { getTemplate } = require('./email-templates');
const template = getTemplate('classicProfessional');
const html = template.render({
  title: 'Test',
  content: '<p>Content</p>'
});
```

## 📦 Bundle Size

The modernized version is more modular, allowing for better tree-shaking:

- **Base utilities**: ~2KB
- **Single template**: ~3KB
- **All templates**: ~35KB
- **Total with all features**: ~40KB

## 🎯 Future Enhancements

- [ ] TypeScript version
- [ ] React component wrappers
- [ ] Email preview server
- [ ] A/B testing utilities
- [ ] Analytics integration
- [ ] Internationalization (i18n)
- [ ] Dark mode variants
- [ ] Accessibility improvements (ARIA labels)

## 📄 Project Files

This package includes:

- **`email-templates.js`** - Main template system (modernized OOP structure)
- **`sendAllTemplates.js`** - Script to send all templates for review
- **`usage-examples.js`** - Comprehensive usage examples
- **`package.json`** - NPM package configuration with scripts
- **`.env.example`** - Environment configuration template
- **`README.md`** - This documentation file
- **`MIGRATION.md`** - Migration guide from old system

## 🔄 Migration Guide

If you're upgrading from the old functional template system, see [MIGRATION.md](./MIGRATION.md) for detailed instructions.

## 📄 License

Same as original CA-Flow project.

## 🤝 Contributing

When adding new templates:
1. Extend `EmailTemplate` class
2. Add to `TemplateRegistry.templates`
3. Update this README
4. Add usage examples
5. Test across email clients

---

**Built with ❤️ for CA-Flow**
