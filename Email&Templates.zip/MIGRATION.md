# Migration Guide: Old to New Template System

This guide helps you migrate from the old functional template system to the new modernized class-based system.

## Quick Start

If you just want to get the new system working quickly:

```bash
# 1. Replace the old template file
cp email-templates.js src/templates/email/email-templates.js

# 2. Update your sending script
cp sendAllTemplates.js src/scripts/sendAllTemplates.js

# 3. Configure environment
cp .env.example .env
# Edit .env with your email credentials

# 4. Install dependencies (if needed)
npm install

# 5. Test it
npm run send:test
```

## Detailed Migration Steps

### Step 1: Update Template File

**Old location:** `src/templates/email/templateCollection.js`  
**New location:** `src/templates/email/email-templates.js`

Replace the entire file with the new `email-templates.js`.

### Step 2: Update Imports Throughout Your Project

#### Before:
```javascript
const {
  template1_ClassicProfessional,
  template2_ModernGradient,
  sampleContent
} = require('./templates/email/templateCollection');

// Usage
const html = template1_ClassicProfessional({
  title: 'Welcome',
  content: sampleContent,
  actionUrl: 'https://example.com',
  actionLabel: 'Click Here'
});
```

#### After:
```javascript
const {
  getTemplate,
  SampleContentGenerator
} = require('./templates/email/email-templates');

// Usage
const template = getTemplate('classicProfessional');
const html = template.render({
  title: 'Welcome',
  content: SampleContentGenerator.createSampleContent('User Name'),
  actionUrl: 'https://example.com',
  actionLabel: 'Click Here'
});
```

### Step 3: Template Name Mapping

Update all references to use the new camelCase keys:

| Old Name | New Key |
|----------|---------|
| `template1_ClassicProfessional` | `'classicProfessional'` |
| `template2_ModernGradient` | `'modernGradient'` |
| `template3_MinimalClean` | `'minimalClean'` |
| `template4_BorderedCard` | `'borderedCard'` |
| `template5_SideAccent` | `'sideAccent'` |
| `template6_DarkHeader` | `'darkHeader'` |
| `template7_SoftRounded` | `'softRounded'` |
| `template8_TwoTone` | `'twoTone'` |
| `template9_ElegantSerif` | `'elegantSerif'` |
| `template10_TechModern` | `'techModern'` |
| `sampleContent` | `SampleContentGenerator.createSampleContent()` |

### Step 4: Update Function Calls

#### Old Pattern:
```javascript
const html = templateFunction({ title, content, actionUrl, actionLabel });
```

#### New Pattern:
```javascript
const template = getTemplate('templateKey');
const html = template.render({ title, content, actionUrl, actionLabel });
```

### Step 5: Update Email Sending Scripts

Replace your `sendAllTemplates.js` with the new version and update imports:

```javascript
// Old
const { template1_ClassicProfessional } = require('./templateCollection');

// New
const { TemplateRegistry } = require('./email-templates');
const template = TemplateRegistry.getTemplate('classicProfessional');
```

## Common Migration Scenarios

### Scenario 1: Simple Email Service

**Before:**
```javascript
// emailService.js (old)
const { template2_ModernGradient } = require('./templates/email/templateCollection');

function sendWelcomeEmail(userEmail, userName) {
  const html = template2_ModernGradient({
    title: 'Welcome to CA-Flow',
    content: `<p>Hello ${userName}!</p>`,
    actionUrl: 'https://ca-flow.com/dashboard',
    actionLabel: 'Get Started'
  });
  
  return sendEmail(userEmail, 'Welcome!', html);
}
```

**After:**
```javascript
// emailService.js (new)
const { getTemplate } = require('./templates/email/email-templates');

class EmailService {
  constructor(defaultTemplate = 'modernGradient') {
    this.defaultTemplate = getTemplate(defaultTemplate);
  }
  
  sendWelcomeEmail(userEmail, userName) {
    const html = this.defaultTemplate.render({
      title: 'Welcome to CA-Flow',
      content: `<p>Hello ${userName}!</p>`,
      actionUrl: 'https://ca-flow.com/dashboard',
      actionLabel: 'Get Started'
    });
    
    return sendEmail(userEmail, 'Welcome!', html);
  }
}

module.exports = new EmailService();
```

### Scenario 2: Dynamic Template Selection

**Before:**
```javascript
const templates = {
  welcome: template1_ClassicProfessional,
  invoice: template9_ElegantSerif,
  notification: template3_MinimalClean
};

function getEmailTemplate(type) {
  return templates[type] || template1_ClassicProfessional;
}
```

**After:**
```javascript
const { getTemplate } = require('./templates/email/email-templates');

const templateMap = {
  welcome: 'classicProfessional',
  invoice: 'elegantSerif',
  notification: 'minimalClean'
};

function getEmailTemplate(type) {
  const templateKey = templateMap[type] || 'classicProfessional';
  return getTemplate(templateKey);
}
```

### Scenario 3: Testing/Preview Generation

**Before:**
```javascript
const { sampleContent, template1_ClassicProfessional } = require('./templateCollection');

function generatePreview(templateFn) {
  return templateFn({
    title: 'Test Email',
    content: sampleContent,
    actionUrl: 'https://example.com',
    actionLabel: 'Test Button'
  });
}

const preview = generatePreview(template1_ClassicProfessional);
```

**After:**
```javascript
const { generateSample } = require('./email-templates');

// Super simple!
const preview = generateSample('classicProfessional');

// Or with custom config
const customPreview = generateSample('classicProfessional', {
  title: 'Test Email',
  content: '<p>Custom test content</p>',
  actionUrl: 'https://example.com',
  actionLabel: 'Test Button'
});
```

## File Structure Changes

### Old Structure:
```
src/
├── templates/
│   └── email/
│       └── templateCollection.js (all templates in one file)
└── scripts/
    └── sendAllTemplates.js
```

### New Structure:
```
src/
├── templates/
│   └── email/
│       └── email-templates.js (modernized OOP structure)
├── scripts/
│   └── sendAllTemplates.js (updated to use new system)
├── package.json (with new scripts)
└── .env.example (email configuration template)
```

## Breaking Changes

1. **Template Functions → Template Classes**
   - Templates are now instances, not functions
   - Use `.render()` method instead of direct invocation

2. **Import Names Changed**
   - All template names changed from `template1_Name` to camelCase keys
   - `sampleContent` is now `SampleContentGenerator.createSampleContent()`

3. **Access Pattern Changed**
   - Must use `getTemplate(key)` instead of importing template directly
   - Or use `TemplateRegistry.getTemplate(key)` for explicit access

4. **Sample Content**
   - Static string → Function that accepts recipient name
   - `sampleContent` → `SampleContentGenerator.createSampleContent('Name')`

## Testing Your Migration

### 1. Unit Test Template Rendering
```javascript
const { getTemplate } = require('./email-templates');

// Test each template renders without errors
['classicProfessional', 'modernGradient', 'minimalClean'].forEach(key => {
  const template = getTemplate(key);
  const html = template.render({
    title: 'Test',
    content: '<p>Test content</p>'
  });
  
  console.assert(html.includes('<!DOCTYPE html>'), `${key} renders HTML`);
  console.assert(html.includes('CA-Flow'), `${key} includes branding`);
});

console.log('✅ All templates render correctly');
```

### 2. Integration Test Email Sending
```javascript
// Use the test command
npm run send:test

// Check your inbox for the test email
```

### 3. Validate All Templates
```javascript
// Send all templates
npm run send:all

// Review all 10 templates in your email client
```

## Rollback Plan

If you need to rollback to the old system:

1. Keep a backup of your old `templateCollection.js`
2. The old and new systems use different import paths
3. Revert imports in your code
4. Restore the old file

```bash
# Backup before migration
cp src/templates/email/templateCollection.js src/templates/email/templateCollection.js.backup

# Rollback if needed
cp src/templates/email/templateCollection.js.backup src/templates/email/templateCollection.js
```

## Benefits After Migration

✅ **Better Organization** - OOP structure is cleaner  
✅ **Easier Testing** - Sample generator included  
✅ **More Flexible** - Easy to customize and extend  
✅ **Better Docs** - JSDoc types for IDE support  
✅ **Less Duplication** - Utility classes reduce repetition  
✅ **Type Safety** - Better autocomplete and validation  
✅ **Easier Maintenance** - Clear separation of concerns  
✅ **Production Ready** - Follows best practices  

## Need Help?

Common issues and solutions:

**Issue**: Template not found  
**Solution**: Check the template key spelling (use `listTemplates()`)

**Issue**: Content not displaying  
**Solution**: Ensure content is valid HTML string

**Issue**: Button not showing  
**Solution**: Both `actionUrl` AND `actionLabel` must be provided

**Issue**: Email not sending  
**Solution**: Verify `.env` configuration, run `npm run send:test`

---

Happy migrating! 🚀
