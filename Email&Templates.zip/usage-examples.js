/**
 * CA-Flow Email Templates - Usage Examples
 * Demonstrates how to use the modernized template system
 */

const {
  TemplateRegistry,
  SampleContentGenerator,
  getTemplate,
  listTemplates,
  generateSample
} = require('./email-templates');

// ============================================================================
// EXAMPLE 1: List all available templates
// ============================================================================

console.log('Available Templates:');
console.log('===================');
const templates = listTemplates();
templates.forEach(({ key, name, description }) => {
  console.log(`${key}: ${name} - ${description}`);
});

// ============================================================================
// EXAMPLE 2: Generate a simple email using a specific template
// ============================================================================

const modernGradientTemplate = getTemplate('modernGradient');
const simpleEmail = modernGradientTemplate.render({
  title: 'Document Upload Successful',
  content: `
    <p style="margin:0 0 16px;">Hello <strong>Manish</strong>,</p>
    <p style="margin:0 0 16px;">Your document has been successfully uploaded to CA-Flow.</p>
    <p style="margin:0;">You can view and manage your documents from the dashboard.</p>
  `,
  actionUrl: 'https://ca-flow.example.com/documents',
  actionLabel: 'View Documents'
});

console.log('\n\nSimple Email HTML:');
console.log(simpleEmail);

// ============================================================================
// EXAMPLE 3: Use the sample content generator
// ============================================================================

const sampleEmail = generateSample('classicProfessional', {
  title: 'Welcome to CA-Flow',
  // Uses default sample content
});

console.log('\n\nSample Email with default content generated');

// ============================================================================
// EXAMPLE 4: Generate emails for all templates (for preview/testing)
// ============================================================================

function generateAllPreviews() {
  const previews = {};
  const templateList = listTemplates();
  
  templateList.forEach(({ key }) => {
    previews[key] = generateSample(key, {
      title: 'Tax Filing Reminder',
      content: `
        <p style="margin:0 0 16px;">Dear Client,</p>
        <p style="margin:0 0 16px;">This is a reminder that your tax filing deadline is approaching.</p>
        <p style="margin:0;">Please ensure all documents are submitted by the due date.</p>
      `,
      actionUrl: 'https://ca-flow.example.com/tax-filing',
      actionLabel: 'Submit Documents'
    });
  });
  
  return previews;
}

const allPreviews = generateAllPreviews();
console.log('\n\nGenerated previews for all templates');

// ============================================================================
// EXAMPLE 5: Dynamic template selection based on email type
// ============================================================================

function sendEmail(emailType, recipient, data) {
  // Map email types to templates
  const templateMap = {
    'welcome': 'modernGradient',
    'notification': 'minimalClean',
    'reminder': 'borderedCard',
    'invoice': 'classicProfessional',
    'alert': 'darkHeader',
    'promotional': 'softRounded'
  };
  
  const templateKey = templateMap[emailType] || 'classicProfessional';
  const template = getTemplate(templateKey);
  
  if (!template) {
    console.error(`Template ${templateKey} not found`);
    return null;
  }
  
  const emailHtml = template.render({
    title: data.title,
    content: data.content,
    actionUrl: data.actionUrl,
    actionLabel: data.actionLabel
  });
  
  // In production, this would send the email via your email service
  console.log(`\nSending ${emailType} email to ${recipient} using ${templateKey} template`);
  
  return emailHtml;
}

// Usage
sendEmail('welcome', 'user@example.com', {
  title: 'Welcome to CA-Flow!',
  content: '<p style="margin:0;">Thank you for joining CA-Flow. We\'re excited to have you!</p>',
  actionUrl: 'https://ca-flow.example.com/getting-started',
  actionLabel: 'Get Started'
});

// ============================================================================
// EXAMPLE 6: Email without action button
// ============================================================================

const notificationEmail = getTemplate('minimalClean').render({
  title: 'Document Processing Complete',
  content: `
    <p style="margin:0 0 16px;">Hello,</p>
    <p style="margin:0 0 16px;">Your documents have been processed successfully.</p>
    <p style="margin:0;">No further action is required at this time.</p>
  `
  // Note: no actionUrl or actionLabel provided
});

console.log('\n\nNotification email without CTA button generated');

// ============================================================================
// EXAMPLE 7: Custom content with HTML formatting
// ============================================================================

const customContent = `
  <p style="margin:0 0 16px;">Dear <strong>Manish Kumar</strong>,</p>
  
  <p style="margin:0 0 16px;">Your quarterly financial report is ready for review.</p>
  
  <table style="width:100%;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;margin:20px 0;">
    <tr style="background:#f9fafb;">
      <th style="padding:12px;text-align:left;font-size:13px;color:#6b7280;">Period</th>
      <th style="padding:12px;text-align:right;font-size:13px;color:#6b7280;">Amount</th>
    </tr>
    <tr>
      <td style="padding:12px;border-top:1px solid #e5e7eb;font-size:14px;">Q1 2025</td>
      <td style="padding:12px;border-top:1px solid #e5e7eb;text-align:right;font-size:14px;font-weight:600;">₹2,45,000</td>
    </tr>
  </table>
  
  <p style="margin:0;">Please review the report and contact us if you have any questions.</p>
`;

const reportEmail = getTemplate('elegantSerif').render({
  title: 'Q1 2025 Financial Report',
  content: customContent,
  actionUrl: 'https://ca-flow.example.com/reports/q1-2025',
  actionLabel: 'View Full Report'
});

console.log('\n\nCustom formatted email generated');

// ============================================================================
// EXAMPLE 8: Batch email generation
// ============================================================================

function generateBatchEmails(recipients, emailData) {
  return recipients.map(recipient => {
    const personalizedContent = emailData.content.replace(
      '{{name}}',
      recipient.name
    );
    
    const template = getTemplate(emailData.templateKey);
    return {
      recipient: recipient.email,
      html: template.render({
        ...emailData,
        content: personalizedContent
      })
    };
  });
}

// Usage
const recipients = [
  { name: 'Manish', email: 'manish@example.com' },
  { name: 'Priya', email: 'priya@example.com' },
  { name: 'Rajesh', email: 'rajesh@example.com' }
];

const batchEmails = generateBatchEmails(recipients, {
  templateKey: 'modernGradient',
  title: 'Year-End Tax Planning Session',
  content: `
    <p style="margin:0 0 16px;">Dear <strong>{{name}}</strong>,</p>
    <p style="margin:0 0 16px;">We're scheduling year-end tax planning sessions for all our clients.</p>
    <p style="margin:0;">Please book your preferred slot using the link below.</p>
  `,
  actionUrl: 'https://ca-flow.example.com/book-session',
  actionLabel: 'Book Session'
});

console.log(`\n\nGenerated ${batchEmails.length} personalized emails`);

// ============================================================================
// EXAMPLE 9: Export single email to file (for testing)
// ============================================================================

const fs = require('fs');
const path = require('path');

function saveEmailPreview(templateKey, filename) {
  const email = generateSample(templateKey);
  const outputPath = path.join(__dirname, 'previews', filename);
  
  // Create previews directory if it doesn't exist
  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(outputPath, email, 'utf8');
  console.log(`\nSaved preview to: ${outputPath}`);
}

// Uncomment to save previews:
// saveEmailPreview('modernGradient', 'modern-gradient-preview.html');

// ============================================================================
// EXAMPLE 10: Template comparison tool
// ============================================================================

function compareTemplates(emailConfig) {
  console.log('\n\nTemplate Comparison');
  console.log('===================');
  
  const templateList = listTemplates();
  const comparison = {};
  
  templateList.forEach(({ key, name }) => {
    const template = getTemplate(key);
    const html = template.render(emailConfig);
    
    comparison[key] = {
      name,
      htmlLength: html.length,
      hasGradient: html.includes('gradient'),
      hasBorder: html.includes('border:') || html.includes('border-'),
      colorScheme: html.includes('#1e3a8a') ? 'Navy' : 
                   html.includes('#2563eb') ? 'Blue' :
                   html.includes('#1f2937') ? 'Dark' : 'Other'
    };
    
    console.log(`${key}: ${comparison[key].htmlLength} chars, ${comparison[key].colorScheme} scheme`);
  });
  
  return comparison;
}

const testConfig = {
  title: 'Test Email',
  content: '<p style="margin:0;">This is a test email for comparison.</p>',
  actionUrl: 'https://example.com',
  actionLabel: 'Click Here'
};

compareTemplates(testConfig);
